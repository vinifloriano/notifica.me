import React from 'react';
import { View } from 'react-native';

function Main() {
    return(
        <View />
    );
}

export default Main;